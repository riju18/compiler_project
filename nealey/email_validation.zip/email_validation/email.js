// Generated automatically by nearley, version 2.11.1
// http://github.com/Hardmath123/nearley
(function () {
function id(x) { return x[0]; }
var grammar = {
    Lexer: undefined,
    ParserRules: [
    {"name": "main$ebnf$1$subexpression$1", "symbols": ["UnderScore"]},
    {"name": "main$ebnf$1", "symbols": ["main$ebnf$1$subexpression$1"], "postprocess": id},
    {"name": "main$ebnf$1", "symbols": [], "postprocess": function(d) {return null;}},
    {"name": "main$ebnf$2$subexpression$1", "symbols": [{"literal":"."}]},
    {"name": "main$ebnf$2", "symbols": ["main$ebnf$2$subexpression$1"], "postprocess": id},
    {"name": "main$ebnf$2", "symbols": [], "postprocess": function(d) {return null;}},
    {"name": "main", "symbols": ["main$ebnf$1", "Start", "Digit", {"literal":"@"}, "Server", {"literal":"."}, "host", "main$ebnf$2", "Start"]},
    {"name": "UnderScore", "symbols": [{"literal":"_"}]},
    {"name": "Start$ebnf$1", "symbols": [/[a-zA-Z]/]},
    {"name": "Start$ebnf$1", "symbols": ["Start$ebnf$1", /[a-zA-Z]/], "postprocess": function arrpush(d) {return d[0].concat([d[1]]);}},
    {"name": "Start", "symbols": ["Start$ebnf$1"]},
    {"name": "Digit$ebnf$1", "symbols": []},
    {"name": "Digit$ebnf$1", "symbols": ["Digit$ebnf$1", /[0-9]/], "postprocess": function arrpush(d) {return d[0].concat([d[1]]);}},
    {"name": "Digit", "symbols": ["Digit$ebnf$1"]},
    {"name": "Server$string$1", "symbols": [{"literal":"y"}, {"literal":"a"}, {"literal":"h"}, {"literal":"o"}, {"literal":"o"}], "postprocess": function joiner(d) {return d.join('');}},
    {"name": "Server", "symbols": ["Server$string$1"]},
    {"name": "Server$string$2", "symbols": [{"literal":"g"}, {"literal":"m"}, {"literal":"a"}, {"literal":"i"}, {"literal":"l"}], "postprocess": function joiner(d) {return d.join('');}},
    {"name": "Server", "symbols": ["Server$string$2"]},
    {"name": "host$string$1", "symbols": [{"literal":"c"}, {"literal":"o"}, {"literal":"m"}], "postprocess": function joiner(d) {return d.join('');}},
    {"name": "host", "symbols": ["host$string$1"]},
    {"name": "host$string$2", "symbols": [{"literal":"o"}, {"literal":"r"}, {"literal":"g"}], "postprocess": function joiner(d) {return d.join('');}},
    {"name": "host", "symbols": ["host$string$2"]},
    {"name": "host$string$3", "symbols": [{"literal":"n"}, {"literal":"e"}, {"literal":"t"}], "postprocess": function joiner(d) {return d.join('');}},
    {"name": "host", "symbols": ["host$string$3"]}
]
  , ParserStart: "main"
}
if (typeof module !== 'undefined'&& typeof module.exports !== 'undefined') {
   module.exports = grammar;
} else {
   window.grammar = grammar;
}
})();
