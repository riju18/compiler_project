// Generated automatically by nearley, version 2.11.1
// http://github.com/Hardmath123/nearley
(function () {
function id(x) { return x[0]; }
var grammar = {
    Lexer: undefined,
    ParserRules: [
    {"name": "main$ebnf$1$subexpression$1", "symbols": ["thirdBracket"]},
    {"name": "main$ebnf$1", "symbols": ["main$ebnf$1$subexpression$1"], "postprocess": id},
    {"name": "main$ebnf$1", "symbols": [], "postprocess": function(d) {return null;}},
    {"name": "main$ebnf$2", "symbols": []},
    {"name": "main$ebnf$2$subexpression$1", "symbols": ["curlibraces"]},
    {"name": "main$ebnf$2", "symbols": ["main$ebnf$2", "main$ebnf$2$subexpression$1"], "postprocess": function arrpush(d) {return d[0].concat([d[1]]);}},
    {"name": "main$ebnf$3", "symbols": []},
    {"name": "main$ebnf$3$subexpression$1", "symbols": ["expression", "op", "expression"]},
    {"name": "main$ebnf$3", "symbols": ["main$ebnf$3", "main$ebnf$3$subexpression$1"], "postprocess": function arrpush(d) {return d[0].concat([d[1]]);}},
    {"name": "main$ebnf$4", "symbols": []},
    {"name": "main$ebnf$4$subexpression$1", "symbols": ["curlibraces"]},
    {"name": "main$ebnf$4", "symbols": ["main$ebnf$4", "main$ebnf$4$subexpression$1"], "postprocess": function arrpush(d) {return d[0].concat([d[1]]);}},
    {"name": "main$ebnf$5$subexpression$1", "symbols": ["thirdBracket"]},
    {"name": "main$ebnf$5", "symbols": ["main$ebnf$5$subexpression$1"], "postprocess": id},
    {"name": "main$ebnf$5", "symbols": [], "postprocess": function(d) {return null;}},
    {"name": "main", "symbols": ["main$ebnf$1", "main$ebnf$2", "main$ebnf$3", "main$ebnf$4", "main$ebnf$5"]},
    {"name": "expression$ebnf$1$subexpression$1$ebnf$1", "symbols": []},
    {"name": "expression$ebnf$1$subexpression$1$ebnf$1$subexpression$1", "symbols": ["parenthesis"]},
    {"name": "expression$ebnf$1$subexpression$1$ebnf$1", "symbols": ["expression$ebnf$1$subexpression$1$ebnf$1", "expression$ebnf$1$subexpression$1$ebnf$1$subexpression$1"], "postprocess": function arrpush(d) {return d[0].concat([d[1]]);}},
    {"name": "expression$ebnf$1$subexpression$1$ebnf$2$subexpression$1", "symbols": ["op"]},
    {"name": "expression$ebnf$1$subexpression$1$ebnf$2", "symbols": ["expression$ebnf$1$subexpression$1$ebnf$2$subexpression$1"], "postprocess": id},
    {"name": "expression$ebnf$1$subexpression$1$ebnf$2", "symbols": [], "postprocess": function(d) {return null;}},
    {"name": "expression$ebnf$1$subexpression$1$ebnf$3", "symbols": []},
    {"name": "expression$ebnf$1$subexpression$1$ebnf$3$subexpression$1", "symbols": ["parenthesis"]},
    {"name": "expression$ebnf$1$subexpression$1$ebnf$3", "symbols": ["expression$ebnf$1$subexpression$1$ebnf$3", "expression$ebnf$1$subexpression$1$ebnf$3$subexpression$1"], "postprocess": function arrpush(d) {return d[0].concat([d[1]]);}},
    {"name": "expression$ebnf$1$subexpression$1", "symbols": ["expression$ebnf$1$subexpression$1$ebnf$1", "digit", "expression$ebnf$1$subexpression$1$ebnf$2", "digit", "expression$ebnf$1$subexpression$1$ebnf$3"]},
    {"name": "expression$ebnf$1", "symbols": ["expression$ebnf$1$subexpression$1"]},
    {"name": "expression$ebnf$1$subexpression$2$ebnf$1", "symbols": []},
    {"name": "expression$ebnf$1$subexpression$2$ebnf$1$subexpression$1", "symbols": ["parenthesis"]},
    {"name": "expression$ebnf$1$subexpression$2$ebnf$1", "symbols": ["expression$ebnf$1$subexpression$2$ebnf$1", "expression$ebnf$1$subexpression$2$ebnf$1$subexpression$1"], "postprocess": function arrpush(d) {return d[0].concat([d[1]]);}},
    {"name": "expression$ebnf$1$subexpression$2$ebnf$2$subexpression$1", "symbols": ["op"]},
    {"name": "expression$ebnf$1$subexpression$2$ebnf$2", "symbols": ["expression$ebnf$1$subexpression$2$ebnf$2$subexpression$1"], "postprocess": id},
    {"name": "expression$ebnf$1$subexpression$2$ebnf$2", "symbols": [], "postprocess": function(d) {return null;}},
    {"name": "expression$ebnf$1$subexpression$2$ebnf$3", "symbols": []},
    {"name": "expression$ebnf$1$subexpression$2$ebnf$3$subexpression$1", "symbols": ["parenthesis"]},
    {"name": "expression$ebnf$1$subexpression$2$ebnf$3", "symbols": ["expression$ebnf$1$subexpression$2$ebnf$3", "expression$ebnf$1$subexpression$2$ebnf$3$subexpression$1"], "postprocess": function arrpush(d) {return d[0].concat([d[1]]);}},
    {"name": "expression$ebnf$1$subexpression$2", "symbols": ["expression$ebnf$1$subexpression$2$ebnf$1", "digit", "expression$ebnf$1$subexpression$2$ebnf$2", "digit", "expression$ebnf$1$subexpression$2$ebnf$3"]},
    {"name": "expression$ebnf$1", "symbols": ["expression$ebnf$1", "expression$ebnf$1$subexpression$2"], "postprocess": function arrpush(d) {return d[0].concat([d[1]]);}},
    {"name": "expression", "symbols": ["expression$ebnf$1"]},
    {"name": "digit$ebnf$1", "symbols": [/[0-9]/]},
    {"name": "digit$ebnf$1", "symbols": ["digit$ebnf$1", /[0-9]/], "postprocess": function arrpush(d) {return d[0].concat([d[1]]);}},
    {"name": "digit", "symbols": ["digit$ebnf$1"]},
    {"name": "op", "symbols": [{"literal":"+"}]},
    {"name": "op", "symbols": [{"literal":"-"}]},
    {"name": "op", "symbols": [{"literal":"*"}]},
    {"name": "op", "symbols": [{"literal":"/"}]},
    {"name": "op", "symbols": [{"literal":"%"}]},
    {"name": "op$string$1", "symbols": [{"literal":"="}, {"literal":" "}], "postprocess": function joiner(d) {return d.join('');}},
    {"name": "op", "symbols": ["op$string$1"]},
    {"name": "op", "symbols": []},
    {"name": "parenthesis", "symbols": [{"literal":"("}]},
    {"name": "parenthesis", "symbols": [{"literal":")"}]},
    {"name": "thirdBracket", "symbols": [{"literal":"["}]},
    {"name": "thirdBracket", "symbols": [{"literal":"]"}]},
    {"name": "curlibraces", "symbols": [{"literal":"{"}]},
    {"name": "curlibraces", "symbols": [{"literal":"}"}]}
]
  , ParserStart: "main"
}
if (typeof module !== 'undefined'&& typeof module.exports !== 'undefined') {
   module.exports = grammar;
} else {
   window.grammar = grammar;
}
})();
