// Generated from c:\javalib\u005Curl_validation - latest\u005Curl.g4 by ANTLR 4.7.1
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class urlParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.7.1", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		T__0=1, T__1=2, T__2=3, T__3=4, Protocol=5, WorldWideWeb=6, Char=7, Anything=8, 
		WS=9;
	public static final int
		RULE_start = 0, RULE_url = 1, RULE_permalink = 2, RULE_extra = 3, RULE_host = 4, 
		RULE_network = 5, RULE_domain = 6, RULE_security_type = 7;
	public static final String[] ruleNames = {
		"start", "url", "permalink", "extra", "host", "network", "domain", "security_type"
	};

	private static final String[] _LITERAL_NAMES = {
		null, "'/'", "'.'", "'?'", "'='", null, "'www.'"
	};
	private static final String[] _SYMBOLIC_NAMES = {
		null, null, null, null, null, "Protocol", "WorldWideWeb", "Char", "Anything", 
		"WS"
	};
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "url.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public urlParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}
	public static class StartContext extends ParserRuleContext {
		public UrlContext url() {
			return getRuleContext(UrlContext.class,0);
		}
		public StartContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_start; }
	}

	public final StartContext start() throws RecognitionException {
		StartContext _localctx = new StartContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_start);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(16);
			url();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class UrlContext extends ParserRuleContext {
		public Security_typeContext security_type() {
			return getRuleContext(Security_typeContext.class,0);
		}
		public NetworkContext network() {
			return getRuleContext(NetworkContext.class,0);
		}
		public DomainContext domain() {
			return getRuleContext(DomainContext.class,0);
		}
		public HostContext host() {
			return getRuleContext(HostContext.class,0);
		}
		public List<ExtraContext> extra() {
			return getRuleContexts(ExtraContext.class);
		}
		public ExtraContext extra(int i) {
			return getRuleContext(ExtraContext.class,i);
		}
		public List<PermalinkContext> permalink() {
			return getRuleContexts(PermalinkContext.class);
		}
		public PermalinkContext permalink(int i) {
			return getRuleContext(PermalinkContext.class,i);
		}
		public UrlContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_url; }
	}

	public final UrlContext url() throws RecognitionException {
		UrlContext _localctx = new UrlContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_url);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(18);
			security_type();
			setState(19);
			network();
			setState(20);
			domain();
			setState(21);
			host();
			setState(25);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==Anything) {
				{
				{
				setState(22);
				extra();
				}
				}
				setState(27);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(31);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(28);
				permalink();
				}
				}
				setState(33);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class PermalinkContext extends ParserRuleContext {
		public List<TerminalNode> Char() { return getTokens(urlParser.Char); }
		public TerminalNode Char(int i) {
			return getToken(urlParser.Char, i);
		}
		public PermalinkContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_permalink; }
	}

	public final PermalinkContext permalink() throws RecognitionException {
		PermalinkContext _localctx = new PermalinkContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_permalink);
		try {
			setState(47);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,2,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				{
				setState(34);
				match(T__0);
				}
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				{
				setState(35);
				match(T__0);
				setState(36);
				match(Char);
				}
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				{
				setState(37);
				match(T__0);
				setState(38);
				match(Char);
				setState(39);
				match(T__1);
				setState(40);
				match(Char);
				}
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				{
				setState(41);
				match(T__0);
				setState(42);
				match(Char);
				setState(43);
				match(T__2);
				setState(44);
				match(Char);
				setState(45);
				match(T__3);
				setState(46);
				match(Char);
				}
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ExtraContext extends ParserRuleContext {
		public TerminalNode Anything() { return getToken(urlParser.Anything, 0); }
		public ExtraContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_extra; }
	}

	public final ExtraContext extra() throws RecognitionException {
		ExtraContext _localctx = new ExtraContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_extra);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(49);
			match(Anything);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class HostContext extends ParserRuleContext {
		public TerminalNode Anything() { return getToken(urlParser.Anything, 0); }
		public HostContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_host; }
	}

	public final HostContext host() throws RecognitionException {
		HostContext _localctx = new HostContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_host);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(51);
			match(Anything);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class NetworkContext extends ParserRuleContext {
		public TerminalNode WorldWideWeb() { return getToken(urlParser.WorldWideWeb, 0); }
		public NetworkContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_network; }
	}

	public final NetworkContext network() throws RecognitionException {
		NetworkContext _localctx = new NetworkContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_network);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(53);
			match(WorldWideWeb);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class DomainContext extends ParserRuleContext {
		public TerminalNode Char() { return getToken(urlParser.Char, 0); }
		public DomainContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_domain; }
	}

	public final DomainContext domain() throws RecognitionException {
		DomainContext _localctx = new DomainContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_domain);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(55);
			match(Char);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Security_typeContext extends ParserRuleContext {
		public TerminalNode Protocol() { return getToken(urlParser.Protocol, 0); }
		public Security_typeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_security_type; }
	}

	public final Security_typeContext security_type() throws RecognitionException {
		Security_typeContext _localctx = new Security_typeContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_security_type);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(57);
			match(Protocol);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3\13>\4\2\t\2\4\3\t"+
		"\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\3\2\3\2\3\3\3\3\3\3"+
		"\3\3\3\3\7\3\32\n\3\f\3\16\3\35\13\3\3\3\7\3 \n\3\f\3\16\3#\13\3\3\4\3"+
		"\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\5\4\62\n\4\3\5\3\5\3\6"+
		"\3\6\3\7\3\7\3\b\3\b\3\t\3\t\3\t\2\2\n\2\4\6\b\n\f\16\20\2\2\2:\2\22\3"+
		"\2\2\2\4\24\3\2\2\2\6\61\3\2\2\2\b\63\3\2\2\2\n\65\3\2\2\2\f\67\3\2\2"+
		"\2\169\3\2\2\2\20;\3\2\2\2\22\23\5\4\3\2\23\3\3\2\2\2\24\25\5\20\t\2\25"+
		"\26\5\f\7\2\26\27\5\16\b\2\27\33\5\n\6\2\30\32\5\b\5\2\31\30\3\2\2\2\32"+
		"\35\3\2\2\2\33\31\3\2\2\2\33\34\3\2\2\2\34!\3\2\2\2\35\33\3\2\2\2\36 "+
		"\5\6\4\2\37\36\3\2\2\2 #\3\2\2\2!\37\3\2\2\2!\"\3\2\2\2\"\5\3\2\2\2#!"+
		"\3\2\2\2$\62\7\3\2\2%&\7\3\2\2&\62\7\t\2\2\'(\7\3\2\2()\7\t\2\2)*\7\4"+
		"\2\2*\62\7\t\2\2+,\7\3\2\2,-\7\t\2\2-.\7\5\2\2./\7\t\2\2/\60\7\6\2\2\60"+
		"\62\7\t\2\2\61$\3\2\2\2\61%\3\2\2\2\61\'\3\2\2\2\61+\3\2\2\2\62\7\3\2"+
		"\2\2\63\64\7\n\2\2\64\t\3\2\2\2\65\66\7\n\2\2\66\13\3\2\2\2\678\7\b\2"+
		"\28\r\3\2\2\29:\7\t\2\2:\17\3\2\2\2;<\7\7\2\2<\21\3\2\2\2\5\33!\61";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}